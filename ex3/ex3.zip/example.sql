insert into donors values('Bob', 'ForStart', 100);
insert into donors values('Linoy', 'ForStart', 100);
insert into donors values('Linoy', 'ForEnd', 100);