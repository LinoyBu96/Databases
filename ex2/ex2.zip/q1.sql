SELECT DISTINCT name
FROM members
WHERE educatedAt = 'Hebrew University of Jerusalem' and birthYear > 1970
ORDER BY name;