CREATE TABLE bestsellers (
    Name varchar,
    Author varchar,
    User_Rating float,
    Reviews integer,
    Price integer,
    Year integer,
    Genre varchar -- forum: without check
)