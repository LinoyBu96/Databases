drop table estimated_in;
drop table closed_university;
drop table university;
drop table country;